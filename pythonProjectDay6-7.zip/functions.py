#
"""
Functions are generally the block of codes or statements in a program
that gives the user the ability to reuse the same code
which ultimately saves the excessive use of memory,
acts as a time saver and more importantly,
provides better readability of the code.
 So basically, a function is a collection of statements that perform
 some specific task and return the result to the caller.
 A function can also perform some specific task without
 returning anything. In Python, def keyword is used to create functions.
"""


# Python program to demonstrate
# functions


# Defining functions
def ask_user():
    print("Hello Sugumar")


# Function that returns sum
# of first 10 numbers
def my_func():
    a = 0
    for i in range(1, 11):
        a = a + i
    return a


# Calling functions
ask_user()
res = my_func()
print(res)

# Function with arguments
"""
Default arguments: A default argument is a parameter that assumes a default value if a value is not provided in the function call for that argument.
"""


# Python program to demonstrate
# default arguments


def myFun(x, y=50):
    print("x: ", x)
    print("y: ", y)


# Driver code
myFun(10)

"""
Keyword arguments: The idea is to allow caller to specify argument name with values so that caller does not need to remember order of parameters.
"""


# Python program to demonstrate Keyword Arguments
def student(firstname, lastname):
    print(firstname, lastname)


# Keyword arguments
student(firstname='Bootcamp', lastname='Practice')
student(lastname='Practice', firstname='Bootcamp')

"""
Variable length arguments: In Python a function can also have variable number of arguments. This can be used in the case when we do not know in advance the number of arguments that will be passed into a function.
"""


# Python program to demonstrate
# variable length arguments
# variable arguments
def myFun1(*argv):
    for arg in argv:
        print(arg, end=" ")

    # variable keyword arguments


def myFun2(**kwargs):
    for key, value in kwargs.items():
        print("% s == % s" % (key, value))

myFun1('Hello', 'Welcome', 'to', 'bootcamp')
print()
myFun2(first='Sugumar', mid='V', last='G')

# # comprehension - special type of syntax in python
# List Comprehension
# # Dictionary Comprehension
# # Set Comprehensions
# # Generator Comprehensions
#
# #Generator - lazy loading function
#
# def print_num(n):
#     l1 = []
#     for each in range(1,n):
#         l1.append(each*each*each)
#     return l1 #all at once
#
# def print_num_gen(n):
#     for each in range(1,n):
#         yield each*each*each
#
# data1 = print_num(10)
# print(data1)
#
# data = print_num_gen(10)
# # print(next(data))
# # print(next(data))
# # print(next(data))
# # print(next(data))
# while True:
#     try:
#         print(next(data))
#     except:
#         break
#
# def get_even_numbers(n):
#     for each in range(1,n):
#         if each % 2 == 0:
#             yield each
#
# evev_num = get_even_numbers(1000)
# while True:
#     try:
#         print(next(data))
#     except:
#         break

#List Comprehension
#output_list = [ output_exp for var in input_list if (var satisfies the condition)]

input_list = [1,2,4,8,9,13,5,43]
print([ each for each in input_list if each % 2 == 0])
print([var**2 for var in range(1,10)])

n1 = list(range(1,10))
for i in range(0,len(n1)):
    n1[i] = n1[i] ** 2
print(n1)
#
# s = [("square",[1,2,3,4,5]),("cube","1,2,3,4,5")]
# o = [ i**2 for i in s for j in i if j == "square" ]

matrix = [[1,2,3],
          [4,5,6],
          [7,8,9]]
flatten_matrix = [val for sublist in matrix for val in sublist]
print(flatten_matrix)

flatten_matrix2 = []
for sublist in matrix:
    for var in sublist:
        flatten_matrix2.append(var)

#dictionary comprehension
#output_dict = {key:value for (key,value) in iterable if (key, value satisfy the condition)}

input_list = [1,2,3,4,5,6,7]
output_dict = {}

#program to have cube of odd numbers {1:1,3:27}
for each in input_list:
    if each %2 != 0:
        output_dict[each] = each ** 3

print(output_dict)

dict_using_comp = {x:x**3 for x in input_list if x %2 !=0}
print(dict_using_comp)

#set comprehension
input_list = [1,2,3,4,5,6,6,6,7,7]

set_using_comp = {var for var in input_list if var %2 == 0}
print(set_using_comp)

#normal for loop convention - output a set which has only the even numbers
output1 = list()
# output = [1,1,2,2,3]
for each in input_list:
    if each % 2 == 0:
        output1.append(each)

print(set(output1))

#generator comprehension
output_gen = (var for var in input_list if var % 2 == 0)
print(type(output_gen))
for var in output_gen:
    print(var)