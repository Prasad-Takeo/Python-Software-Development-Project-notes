#Object Orient Programming

#functional and object-oriented programming

#object-oriented programming follow entities and relationships

#in-real-world
#
# Animals -> class
# lion -> object of animal class
# each object possess it's own charecteristic that will become a method or varible

# sound - characterstic
# lion -
# cat -
# elephant -

#banking
# account - class
# savings, current, FD, RD

# interest rate - characteristic
# saving account - 0.5
# current account - 0.5
# FD - 2
# RD - 5

#class, objects, inheritance, encapsulation, polymorphism

#encapsulation - binding data and method together
# interest_rate - data
# get_interest_rate() method which uses interest_rate data

#Account B having 1000$ in FD and what will be rate of interest
# 1000$ * 2 -> get_interest_rate()

#inheritance - kind of common characteristic upon parent - child
#Account - credit and debit
#Animals - sound
#elephant
#lion

class Person():
    name

class Employee(Person):
    name

class SportsPerson(Person):
    name

#polymorphism - taking one more than one form, operator overlaoding,
#function overloading - same name but with different number / type of arguments
class Volume
    def volume(self):

class Cube(volume): a*a*a

class Square(volume):a*a

class Circle(volume): pi * r * r